import { useState } from 'react';
import { Card } from './ui/card';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Eye, Edit, Search } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Label } from './ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from './ui/sheet';
import { AvailabilityScheduler, AvailabilityData } from './AvailabilityScheduler';

interface FacultyHubProps {
  userRole?: 'admin' | 'program-head' | 'faculty' | null;
  userDepartment?: string;
}

export function FacultyHub({ userRole, userDepartment }: FacultyHubProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDept, setSelectedDept] = useState('all');
  const [selectedClass, setSelectedClass] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [viewingFaculty, setViewingFaculty] = useState<any>(null);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [selectedClassification, setSelectedClassification] = useState('Full-Time');
  const [availability, setAvailability] = useState<AvailabilityData | undefined>();

  const facultyData = [
    {
      id: 'F-001',
      name: 'Alejandro Burgos Jr.',
      department: 'ICT',
      classification: 'Full-Time',
      currentLoad: '18/30',
      loadValue: 18,
      maxLoad: 30,
      status: 'ACTIVE',
      email: 'a.burgos@sti.edu.ph',
      contact: '09171234567',
      specialization: 'Web Development, Database Management',
      adviser: 'BSIT-1A',
      preferredSubjects: 'IT101, IT102, IT201'
    },
    {
      id: 'F-002',
      name: 'Ma. Claret R. Delos Santos',
      department: 'ICT',
      classification: 'Full-Time',
      currentLoad: '21/30',
      loadValue: 21,
      maxLoad: 30,
      status: 'ACTIVE',
      email: 'claret.delos@sti.edu.ph',
      contact: '09171234568',
      specialization: 'Programming, Software Engineering',
      adviser: '',
      preferredSubjects: 'IT102, IT201'
    },
    {
      id: 'F-003',
      name: 'John Vincent C. Malquisto',
      department: 'ICT',
      classification: 'Part-Time',
      currentLoad: '15/30',
      loadValue: 15,
      maxLoad: 30,
      status: 'ACTIVE',
      email: 'jv.malquisto@sti.edu.ph',
      contact: '09171234569',
      specialization: 'Database Systems',
      adviser: '',
      preferredSubjects: 'CS201, IT301'
    },
    {
      id: 'F-004',
      name: 'Andrea L. Ponteres',
      department: 'Business Management',
      classification: 'Full-Time',
      currentLoad: '22/30',
      loadValue: 22,
      maxLoad: 30,
      status: 'ACTIVE',
      email: 'andrea.ponteres@sti.edu.ph',
      contact: '09171234570',
      specialization: 'Business Administration',
      adviser: '',
      preferredSubjects: 'BM101'
    },
    {
      id: 'F-005',
      name: 'Airol Jay M. Zabala',
      department: 'TMHM',
      classification: 'Part-Time Full Load',
      currentLoad: '20/30',
      loadValue: 20,
      maxLoad: 30,
      status: 'ACTIVE',
      email: 'airol.zabala@sti.edu.ph',
      contact: '09171234571',
      specialization: 'Tourism Management',
      adviser: '',
      preferredSubjects: ''
    },
    {
      id: 'F-006',
      name: 'Mark Albert D. Natividad',
      department: 'General Education',
      classification: 'Full-Time',
      currentLoad: '15/30',
      loadValue: 15,
      maxLoad: 30,
      status: 'ACTIVE',
      email: 'mark.natividad@sti.edu.ph',
      contact: '09171234572',
      specialization: 'Mathematics',
      adviser: '',
      preferredSubjects: 'CS101'
    }
  ];

  const filteredFaculty = facultyData.filter(faculty => {
    const matchesSearch = faculty.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          faculty.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDept = selectedDept === 'all' || faculty.department === selectedDept;
    const matchesClass = selectedClass === 'all' || faculty.classification === selectedClass;
    const matchesStatus = selectedStatus === 'all' || faculty.status === selectedStatus;

    // If user is program head, only show faculty from their department
    const matchesUserDept = userRole !== 'program-head' || (userDepartment && faculty.department === userDepartment);

    return matchesSearch && matchesDept && matchesClass && matchesStatus && matchesUserDept;
  });

  const getLoadColor = (loadValue: number, maxLoad: number) => {
    const percentage = (loadValue / maxLoad) * 100;
    if (percentage >= 90) return '#EF4444';
    if (percentage >= 70) return '#FFD400';
    return '#22C55E';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl mb-1" style={{ color: '#002B7F', fontWeight: 700 }}>
            Faculty Hub
          </h1>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button style={{ backgroundColor: '#002B7F', color: 'white', fontWeight: 600 }}>
              + Add Faculty
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle style={{ color: '#002B7F', fontWeight: 700 }}>Add Faculty</DialogTitle>
            </DialogHeader>
            <div className="grid grid-cols-2 gap-4 py-4">
              <div className="space-y-2">
                <Label className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>FACULTY ID</Label>
                <Input placeholder="F-007" />
              </div>
              <div className="space-y-2">
                <Label className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>STATUS</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Active" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Active">Active</SelectItem>
                    <SelectItem value="Inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>FIRST NAME</Label>
                <Input placeholder="First name" />
              </div>
              <div className="space-y-2">
                <Label className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>MIDDLE NAME</Label>
                <Input placeholder="Middle name" />
              </div>
              <div className="space-y-2">
                <Label className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>LAST NAME</Label>
                <Input placeholder="Last name" />
              </div>
              <div className="space-y-2">
                <Label className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>DEPARTMENT</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="ICT" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ICT">ICT</SelectItem>
                    <SelectItem value="Business Management">Business Management</SelectItem>
                    <SelectItem value="General Education">General Education</SelectItem>
                    <SelectItem value="TMHM">TMHM</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>EMAIL</Label>
                <Input placeholder="name@sti.edu.ph" />
              </div>
              <div className="space-y-2">
                <Label className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>CONTACT</Label>
                <Input placeholder="09XXXXXXXXX" />
              </div>
              <div className="space-y-2">
                <Label className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>CLASSIFICATION</Label>
                <Select value={selectedClassification} onValueChange={setSelectedClassification}>
                  <SelectTrigger>
                    <SelectValue placeholder="Full-Time" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Full-Time">Full-Time</SelectItem>
                    <SelectItem value="Part-Time">Part-Time</SelectItem>
                    <SelectItem value="Part-Time Full Load">Part-Time Full Load</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>SPECIALIZATION</Label>
                <Input placeholder="e.g. Web Dev" />
              </div>
              <div className="space-y-2 col-span-2">
                <Label className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>PREFERRED SUBJECTS</Label>
                <Input placeholder="e.g. IT101, IT102" />
              </div>
            </div>
            {(selectedClassification === 'Part-Time' || selectedClassification === 'Part-Time Full Load') && (
              <div className="py-4 border-t">
                <AvailabilityScheduler value={availability} onChange={setAvailability} />
              </div>
            )}
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>Cancel</Button>
              <Button style={{ backgroundColor: '#002B7F', color: 'white' }} onClick={() => setIsAddDialogOpen(false)}>Save Faculty</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="p-6 border border-gray-200">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
            <Input
              placeholder="Search faculty..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={selectedDept} onValueChange={setSelectedDept}>
            <SelectTrigger>
              <SelectValue placeholder="All Departments" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Departments</SelectItem>
              <SelectItem value="ICT">ICT</SelectItem>
              <SelectItem value="Business Management">Business Management</SelectItem>
              <SelectItem value="General Education">General Education</SelectItem>
              <SelectItem value="TMHM">TMHM</SelectItem>
            </SelectContent>
          </Select>
          <Select value={selectedClass} onValueChange={setSelectedClass}>
            <SelectTrigger>
              <SelectValue placeholder="All Classifications" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Classifications</SelectItem>
              <SelectItem value="Full-Time">Full-Time</SelectItem>
              <SelectItem value="Part-Time">Part-Time</SelectItem>
              <SelectItem value="Part-Time Full Load">Part-Time Full Load</SelectItem>
            </SelectContent>
          </Select>
          <Select value={selectedStatus} onValueChange={setSelectedStatus}>
            <SelectTrigger>
              <SelectValue placeholder="All Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="ACTIVE">Active</SelectItem>
              <SelectItem value="ON LOA">On LOA</SelectItem>
              <SelectItem value="EMERGENCY LEAVE">Emergency Leave</SelectItem>
              <SelectItem value="INACTIVE">Inactive</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b-2" style={{ borderColor: '#002B7F' }}>
                <th className="text-left py-3 px-4" style={{ color: '#002B7F', fontWeight: 600 }}>FACULTY ID</th>
                <th className="text-left py-3 px-4" style={{ color: '#002B7F', fontWeight: 600 }}>NAME</th>
                <th className="text-left py-3 px-4" style={{ color: '#002B7F', fontWeight: 600 }}>DEPARTMENT</th>
                <th className="text-left py-3 px-4" style={{ color: '#002B7F', fontWeight: 600 }}>CLASSIFICATION</th>
                <th className="text-left py-3 px-4" style={{ color: '#002B7F', fontWeight: 600 }}>CURRENT LOAD</th>
                <th className="text-left py-3 px-4" style={{ color: '#002B7F', fontWeight: 600 }}>STATUS</th>
                <th className="text-left py-3 px-4" style={{ color: '#002B7F', fontWeight: 600 }}>ACTIONS</th>
              </tr>
            </thead>
            <tbody>
              {filteredFaculty.map((faculty) => (
                <tr key={faculty.id} className="border-b border-gray-200 hover:bg-gray-50">
                  <td className="py-3 px-4" style={{ color: '#002B7F', fontWeight: 600 }}>{faculty.id}</td>
                  <td className="py-3 px-4" style={{ color: '#333333', fontWeight: 500 }}>{faculty.name}</td>
                  <td className="py-3 px-4" style={{ color: '#666666' }}>{faculty.department}</td>
                  <td className="py-3 px-4" style={{ color: '#666666' }}>{faculty.classification}</td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      <div className="w-16 h-2 bg-gray-200 rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full"
                          style={{
                            width: `${(faculty.loadValue / faculty.maxLoad) * 100}%`,
                            backgroundColor: getLoadColor(faculty.loadValue, faculty.maxLoad)
                          }}
                        />
                      </div>
                      <span style={{ color: '#333333', fontWeight: 600 }}>{faculty.currentLoad}</span>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className="px-3 py-1 rounded text-sm"
                      style={{ backgroundColor: '#22C55E', color: 'white', fontWeight: 600 }}
                    >
                      {faculty.status}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex gap-2">
                      <button
                        className="p-1 hover:bg-gray-100 rounded"
                        onClick={() => {
                          setViewingFaculty(faculty);
                          setIsProfileOpen(true);
                        }}
                      >
                        <Eye size={18} style={{ color: '#666666' }} />
                      </button>
                      <button
                        className="p-1 hover:bg-gray-100 rounded"
                        onClick={() => {
                          setViewingFaculty(faculty);
                          setIsEditDialogOpen(true);
                        }}
                      >
                        <Edit size={18} style={{ color: '#666666' }} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <Sheet open={isProfileOpen} onOpenChange={setIsProfileOpen}>
        <SheetContent className="w-[900px] sm:w-[900px] max-w-[90vw] overflow-y-auto p-8">
          <SheetHeader className="border-b pb-6 mb-6">
            <SheetTitle style={{ color: '#002B7F', fontWeight: 700, fontSize: '1.5rem' }}>
              Faculty Profile — {viewingFaculty?.id}
            </SheetTitle>
          </SheetHeader>
          {viewingFaculty && (
            <Tabs defaultValue="profile" className="mt-6">
              <TabsList className="w-full grid grid-cols-5">
                <TabsTrigger value="profile">Profile</TabsTrigger>
                <TabsTrigger value="workload">Workload</TabsTrigger>
                <TabsTrigger value="schedule">Schedule</TabsTrigger>
                <TabsTrigger value="qualifications">Qualifications</TabsTrigger>
                <TabsTrigger value="availability">Availability</TabsTrigger>
              </TabsList>
              <TabsContent value="profile" className="space-y-10 mt-8">
                <div className="flex items-start gap-6 pb-8 border-b">
                  <div
                    className="w-20 h-20 flex-shrink-0 flex items-center justify-center rounded-lg"
                    style={{ backgroundColor: '#002B7F', color: 'white', fontSize: '1.75rem', fontWeight: 700 }}
                  >
                    {viewingFaculty.name.split(' ').map((n: string) => n[0]).join('').slice(0, 2).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-2xl mb-2" style={{ color: '#002B7F', fontWeight: 700 }}>
                      {viewingFaculty.name}
                    </h3>
                    <p style={{ color: '#666666', fontSize: '1rem' }}>{viewingFaculty.id} — {viewingFaculty.department}</p>
                  </div>
                </div>

                <div className="space-y-10">
                  <div className="grid grid-cols-2 gap-x-16 gap-y-10">
                    <div className="space-y-2">
                      <Label className="text-sm block" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px' }}>FACULTY ID</Label>
                      <p className="break-words" style={{ color: '#002B7F', fontWeight: 600, fontSize: '1.125rem', lineHeight: '1.8' }}>{viewingFaculty.id}</p>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-sm block" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px' }}>DEPARTMENT</Label>
                      <p className="break-words" style={{ color: '#333333', fontWeight: 600, fontSize: '1.125rem', lineHeight: '1.8' }}>{viewingFaculty.department}</p>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-sm block" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px' }}>CLASSIFICATION</Label>
                      <p className="break-words" style={{ color: '#333333', fontWeight: 600, fontSize: '1.125rem', lineHeight: '1.8' }}>{viewingFaculty.classification}</p>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-sm block" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px' }}>STATUS</Label>
                      <span
                        className="px-4 py-2 rounded text-base inline-block"
                        style={{ backgroundColor: '#22C55E', color: 'white', fontWeight: 600 }}
                      >
                        {viewingFaculty.status}
                      </span>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-sm block" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px' }}>EMAIL</Label>
                      <p className="break-words" style={{ color: '#333333', fontWeight: 500, fontSize: '1.0625rem', lineHeight: '1.8' }}>{viewingFaculty.email}</p>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-sm block" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px' }}>CONTACT</Label>
                      <p className="break-words" style={{ color: '#333333', fontWeight: 500, fontSize: '1.0625rem', lineHeight: '1.8' }}>{viewingFaculty.contact}</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-sm block" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px' }}>SPECIALIZATION</Label>
                    <p className="break-words" style={{ color: '#333333', fontWeight: 500, fontSize: '1.0625rem', lineHeight: '1.8' }}>{viewingFaculty.specialization}</p>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-sm block" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px' }}>ADVISER OF</Label>
                    <p className="break-words" style={{ color: '#002B7F', fontWeight: 600, fontSize: '1.125rem', lineHeight: '1.8' }}>{viewingFaculty.adviser || 'Not assigned'}</p>
                  </div>
                </div>

                <div className="flex gap-3 pt-6 border-t">
                  <Button style={{ backgroundColor: '#002B7F', color: 'white' }} size="sm" className="flex items-center gap-1">
                    <Edit size={16} />
                    Edit
                  </Button>
                  <Button style={{ backgroundColor: '#002B7F', color: 'white' }} size="sm">
                    Schedule
                  </Button>
                  <Button style={{ backgroundColor: '#FFD400', color: '#002B7F' }} size="sm">
                    Status
                  </Button>
                  <Button style={{ backgroundColor: '#EF4444', color: 'white' }} size="sm">
                    Archive
                  </Button>
                </div>
              </TabsContent>
              <TabsContent value="workload" className="mt-6">
                <p style={{ color: '#666666' }}>Workload information will be displayed here</p>
              </TabsContent>
              <TabsContent value="schedule" className="mt-6">
                <p style={{ color: '#666666' }}>Schedule information will be displayed here</p>
              </TabsContent>
              <TabsContent value="qualifications" className="mt-6">
                <p style={{ color: '#666666' }}>Qualifications information will be displayed here</p>
              </TabsContent>
              <TabsContent value="availability" className="mt-6">
                <p style={{ color: '#666666' }}>Availability information will be displayed here</p>
              </TabsContent>
            </Tabs>
          )}
        </SheetContent>
      </Sheet>

      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle style={{ color: '#002B7F', fontWeight: 700 }}>Edit Faculty</DialogTitle>
          </DialogHeader>
          {viewingFaculty && (
            <div className="grid grid-cols-2 gap-4 py-4">
              <div className="space-y-2">
                <Label className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>ID</Label>
                <Input value={viewingFaculty.id} readOnly />
              </div>
              <div className="space-y-2">
                <Label className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>STATUS</Label>
                <Select defaultValue="Active">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Active">Active</SelectItem>
                    <SelectItem value="Inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>FIRST NAME</Label>
                <Input defaultValue={viewingFaculty.name.split(' ')[0]} />
              </div>
              <div className="space-y-2">
                <Label className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>MIDDLE NAME</Label>
                <Input placeholder="Middle name" />
              </div>
              <div className="space-y-2">
                <Label className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>LAST NAME</Label>
                <Input defaultValue={viewingFaculty.name.split(' ').slice(-1)[0]} />
              </div>
              <div className="space-y-2">
                <Label className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>DEPARTMENT</Label>
                <Select defaultValue={viewingFaculty.department}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ICT">ICT</SelectItem>
                    <SelectItem value="Business Management">Business Management</SelectItem>
                    <SelectItem value="General Education">General Education</SelectItem>
                    <SelectItem value="TMHM">TMHM</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>EMAIL</Label>
                <Input defaultValue={viewingFaculty.email} />
              </div>
              <div className="space-y-2">
                <Label className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>CONTACT</Label>
                <Input defaultValue={viewingFaculty.contact} />
              </div>
              <div className="space-y-2">
                <Label className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>CLASSIFICATION</Label>
                <Select defaultValue={viewingFaculty.classification}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Full-Time">Full-Time</SelectItem>
                    <SelectItem value="Part-Time">Part-Time</SelectItem>
                    <SelectItem value="Part-Time Full Load">Part-Time Full Load</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>SPECIALIZATION</Label>
                <Input defaultValue={viewingFaculty.specialization} />
              </div>
              <div className="space-y-2 col-span-2">
                <Label className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>PREFERRED SUBJECTS</Label>
                <Input defaultValue={viewingFaculty.preferredSubjects} />
              </div>
            </div>
          )}
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>Cancel</Button>
            <Button style={{ backgroundColor: '#002B7F', color: 'white' }} onClick={() => setIsEditDialogOpen(false)}>Update</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
