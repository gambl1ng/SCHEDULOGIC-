import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Eye, Edit, Search } from 'lucide-react';

interface CurriculumManagementProps {
  userRole?: 'admin' | 'program-head' | 'faculty' | null;
}

export function CurriculumManagement({ userRole }: CurriculumManagementProps) {
  const [selectedProgram, setSelectedProgram] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [isAddCourseOpen, setIsAddCourseOpen] = useState(false);
  const isViewOnly = userRole === 'program-head';

  const curriculumData = {
    'BSIT 2023': [
      { code: 'IT101', title: 'Introduction to Computing', credit: 3, lec: 2, lab: 1, preReq: '—', status: 'ACTIVE' },
      { code: 'IT102', title: 'Computer Programming 1', credit: 3, lec: 2, lab: 1, preReq: 'IT101', status: 'ACTIVE' },
      { code: 'IT201', title: 'Computer Programming 2', credit: 3, lec: 2, lab: 1, preReq: 'IT102', status: 'ACTIVE' },
      { code: 'IT301', title: 'Web Development', credit: 3, lec: 1, lab: 2, preReq: 'IT201', status: 'ACTIVE' },
      { code: 'CS101', title: 'Discrete Mathematics', credit: 3, lec: 3, lab: 0, preReq: '—', status: 'ACTIVE' },
      { code: 'CS201', title: 'Data Structures', credit: 3, lec: 2, lab: 1, preReq: 'CS101', status: 'ACTIVE' },
    ],
    'BSBA 2023': [
      { code: 'BM101', title: 'Principles of Management', credit: 3, lec: 3, lab: 0, preReq: '—', status: 'ACTIVE' },
      { code: 'BM201', title: 'Marketing Management', credit: 3, lec: 3, lab: 0, preReq: 'BM101', status: 'ACTIVE' },
    ]
  };

  const programs = Object.keys(curriculumData);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl mb-1" style={{ color: '#002B7F', fontWeight: 700 }}>
            Curriculum Management {isViewOnly && '(View Only)'}
          </h1>
        </div>
        {!isViewOnly && (
          <Button
            style={{ backgroundColor: '#002B7F', color: 'white', fontWeight: 600 }}
            onClick={() => setIsAddCourseOpen(true)}
          >
            Add Course
          </Button>
        )}
      </div>

      <Card className="p-6 border border-gray-200">
        <div className="flex gap-4 mb-6">
          <Select value={selectedProgram} onValueChange={setSelectedProgram}>
            <SelectTrigger className="w-64">
              <SelectValue placeholder="All Programs" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Programs</SelectItem>
              <SelectItem value="BSIT 2023">BSIT 2023</SelectItem>
              <SelectItem value="BSBA 2023">BSBA 2023</SelectItem>
            </SelectContent>
          </Select>
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
            <Input
              placeholder="Search courses..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {(selectedProgram === 'all' ? programs : [selectedProgram]).map((program) => (
          <div key={program} className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl" style={{ color: '#002B7F', fontWeight: 700 }}>
                {program}
              </h2>
              <span style={{ color: '#002B7F', fontWeight: 600 }}>
                {curriculumData[program as keyof typeof curriculumData].length} COURSES
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b-2" style={{ borderColor: '#002B7F' }}>
                    <th className="text-left py-3 px-4" style={{ color: '#002B7F', fontWeight: 600 }}>CODE</th>
                    <th className="text-left py-3 px-4" style={{ color: '#002B7F', fontWeight: 600 }}>TITLE</th>
                    <th className="text-left py-3 px-4" style={{ color: '#002B7F', fontWeight: 600 }}>CREDIT</th>
                    <th className="text-left py-3 px-4" style={{ color: '#002B7F', fontWeight: 600 }}>LEC</th>
                    <th className="text-left py-3 px-4" style={{ color: '#002B7F', fontWeight: 600 }}>LAB</th>
                    <th className="text-left py-3 px-4" style={{ color: '#002B7F', fontWeight: 600 }}>PRE-REQ</th>
                    <th className="text-left py-3 px-4" style={{ color: '#002B7F', fontWeight: 600 }}>STATUS</th>
                    <th className="text-left py-3 px-4" style={{ color: '#002B7F', fontWeight: 600 }}>ACTION</th>
                  </tr>
                </thead>
                <tbody>
                  {curriculumData[program as keyof typeof curriculumData].map((course) => (
                    <tr key={course.code} className="border-b border-gray-200 hover:bg-gray-50">
                      <td className="py-3 px-4" style={{ color: '#002B7F', fontWeight: 600 }}>{course.code}</td>
                      <td className="py-3 px-4" style={{ color: '#333333' }}>{course.title}</td>
                      <td className="py-3 px-4" style={{ color: '#666666' }}>{course.credit}</td>
                      <td className="py-3 px-4" style={{ color: '#666666' }}>{course.lec}</td>
                      <td className="py-3 px-4" style={{ color: '#666666' }}>{course.lab}</td>
                      <td className="py-3 px-4" style={{ color: '#666666' }}>{course.preReq}</td>
                      <td className="py-3 px-4">
                        <span
                          className="px-3 py-1 rounded text-sm"
                          style={{ backgroundColor: '#22C55E', color: 'white', fontWeight: 600 }}
                        >
                          {course.status}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex gap-2">
                          <button className="p-1 hover:bg-gray-100 rounded">
                            <Eye size={18} style={{ color: '#666666' }} />
                          </button>
                          {!isViewOnly && (
                            <button className="p-1 hover:bg-gray-100 rounded">
                              <Edit size={18} style={{ color: '#666666' }} />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ))}
      </Card>

      <Dialog open={isAddCourseOpen} onOpenChange={setIsAddCourseOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle style={{ color: '#002B7F', fontWeight: 700 }}>Add Course</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-4">
            <div className="space-y-2">
              <Label className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>COURSE CODE</Label>
              <Input placeholder="e.g. IT401" />
            </div>
            <div className="space-y-2">
              <Label className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>PROGRAM</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="BSIT 2023" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="BSIT 2023">BSIT 2023</SelectItem>
                  <SelectItem value="BSBA 2023">BSBA 2023</SelectItem>
                  <SelectItem value="BSHM 2023">BSHM 2023</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2 col-span-2">
              <Label className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>COURSE TITLE</Label>
              <Input placeholder="e.g. Advanced Web Development" />
            </div>
            <div className="space-y-2">
              <Label className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>CREDIT</Label>
              <Input type="number" placeholder="3" />
            </div>
            <div className="space-y-2">
              <Label className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>LEC HOURS</Label>
              <Input type="number" placeholder="2" />
            </div>
            <div className="space-y-2">
              <Label className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>LAB HOURS</Label>
              <Input type="number" placeholder="1" />
            </div>
            <div className="space-y-2">
              <Label className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>STATUS</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Active" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Active">Active</SelectItem>
                  <SelectItem value="Inactive">Inactive</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-4">
            <Button variant="outline" onClick={() => setIsAddCourseOpen(false)}>Cancel</Button>
            <Button style={{ backgroundColor: '#002B7F', color: 'white' }} onClick={() => setIsAddCourseOpen(false)}>Add Course</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
