import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import stiLogo from '../../imports/images__10_.png';

interface SignInProps {
  onSignIn: (role: 'admin' | 'program-head' | 'faculty') => void;
}

export function SignIn({ onSignIn }: SignInProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<'admin' | 'program-head' | 'faculty' | ''>('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (role) {
      onSignIn(role);
    }
  };

  return (
    <div className="min-h-screen flex">
      <div className="w-1/2 flex flex-col items-center justify-center" style={{ backgroundColor: '#002B7F' }}>
        <div className="mb-8">
          <img
            src={stiLogo}
            alt="STI"
            className="w-40 h-40 object-contain"
          />
        </div>
        <h1 className="text-4xl mb-3" style={{ color: 'white', fontWeight: 700 }}>
          ScheduLogic
        </h1>
        <p className="text-base text-center px-8" style={{ color: 'rgba(255, 255, 255, 0.9)', fontWeight: 400 }}>
          An Intelligent Scheduling System
        </p>
        <p className="text-sm mt-2" style={{ color: 'rgba(255, 255, 255, 0.7)', fontWeight: 400 }}>
          for STI College Balagtas
        </p>
      </div>

      <div className="w-1/2 flex items-center justify-center bg-white">
        <div className="w-full max-w-md px-12">
          <div className="mb-8">
            <h2 className="text-2xl mb-2" style={{ color: '#002B7F', fontWeight: 700 }}>
              Sign In
            </h2>
            <p className="text-sm" style={{ color: '#666666', fontWeight: 400 }}>
              Enter your credentials to access the system.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="username" className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>
                Username
              </Label>
              <Input
                id="username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter your username"
                required
                className="h-11 border-gray-300 focus:border-[#002B7F] focus:ring-[#002B7F]"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>
                Password
              </Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
                required
                className="h-11 border-gray-300 focus:border-[#002B7F] focus:ring-[#002B7F]"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="role" className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>
                Role
              </Label>
              <Select value={role} onValueChange={(value: any) => setRole(value)} required>
                <SelectTrigger className="h-11 border-gray-300">
                  <SelectValue placeholder="Administrator" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">Administrator</SelectItem>
                  <SelectItem value="program-head">Program Head</SelectItem>
                  <SelectItem value="faculty">Faculty</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Button
              type="submit"
              className="w-full h-11 text-base mt-6"
              style={{
                backgroundColor: '#002B7F',
                color: 'white',
                fontWeight: 600
              }}
            >
              Sign In
            </Button>
          </form>

          <div className="mt-8 text-center text-xs" style={{ color: '#999999' }}>
            ScheduLogic v2.1 © 2026 STI College Balagtas
          </div>
        </div>
      </div>
    </div>
  );
}
