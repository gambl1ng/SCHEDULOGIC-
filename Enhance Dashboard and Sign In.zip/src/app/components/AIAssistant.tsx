import { useState } from 'react';
import { MessageCircle, X, Send } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card } from './ui/card';

export function AIAssistant() {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<{ text: string; isUser: boolean }[]>([
    { text: 'Hello! I\'m your AI scheduling assistant. How can I help you today?', isUser: false }
  ]);

  const handleSend = () => {
    if (!message.trim()) return;

    setMessages([...messages, { text: message, isUser: true }]);
    setMessage('');

    // Simulate AI response
    setTimeout(() => {
      setMessages(prev => [...prev, {
        text: 'I can help you with scheduling, faculty management, and answer questions about the system. What would you like to know?',
        isUser: false
      }]);
    }, 1000);
  };

  return (
    <>
      {isOpen && (
        <Card className="fixed bottom-24 right-6 w-96 h-[500px] flex flex-col shadow-2xl border-2 z-50" style={{ borderColor: '#002B7F' }}>
          <div className="flex items-center justify-between p-4 border-b" style={{ backgroundColor: '#002B7F' }}>
            <div className="flex items-center gap-2">
              <MessageCircle size={20} style={{ color: 'white' }} />
              <h3 className="font-semibold" style={{ color: 'white' }}>AI Assistant</h3>
            </div>
            <button onClick={() => setIsOpen(false)} className="hover:bg-blue-800 p-1 rounded">
              <X size={20} style={{ color: 'white' }} />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
            {messages.map((msg, index) => (
              <div key={index} className={`flex ${msg.isUser ? 'justify-end' : 'justify-start'}`}>
                <div
                  className="max-w-[80%] p-3 rounded-lg"
                  style={{
                    backgroundColor: msg.isUser ? '#002B7F' : 'white',
                    color: msg.isUser ? 'white' : '#333333',
                    border: msg.isUser ? 'none' : '1px solid #E5E7EB'
                  }}
                >
                  <p className="text-sm">{msg.text}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="p-4 border-t bg-white">
            <div className="flex gap-2">
              <Input
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Ask me anything..."
                className="flex-1"
              />
              <Button
                onClick={handleSend}
                style={{ backgroundColor: '#002B7F', color: 'white' }}
                size="sm"
              >
                <Send size={18} />
              </Button>
            </div>
          </div>
        </Card>
      )}

      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-6 w-14 h-14 rounded-full shadow-lg flex items-center justify-center hover:scale-110 transition-transform z-50"
        style={{ backgroundColor: '#FFD400' }}
      >
        {isOpen ? (
          <X size={24} style={{ color: '#002B7F' }} />
        ) : (
          <MessageCircle size={24} style={{ color: '#002B7F' }} />
        )}
      </button>
    </>
  );
}
