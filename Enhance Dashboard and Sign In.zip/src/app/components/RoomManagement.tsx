import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Eye, Edit, Trash2, Search } from 'lucide-react';

interface RoomManagementProps {
  userRole?: 'admin' | 'program-head' | 'faculty' | null;
}

export function RoomManagement({ userRole }: RoomManagementProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const isViewOnly = userRole === 'program-head';

  const rooms = [
    { code: 'R-101', name: 'Room 101', building: 'Old Building', floor: '1st Floor', type: 'Lecture Room', capacity: 40, status: 'ACTIVE' },
    { code: 'R-102', name: 'Room 102', building: 'Old Building', floor: '1st Floor', type: 'Lecture Room', capacity: 45, status: 'ACTIVE' },
    { code: 'R-201', name: 'Room 201', building: 'Annex Building', floor: '2nd Floor', type: 'Lecture Room', capacity: 35, status: 'ACTIVE' },
    { code: 'CL-101', name: 'Computer Lab A', building: 'Old Building', floor: '1st Floor', type: 'Computer Laboratory A', capacity: 30, status: 'ACTIVE' },
    { code: 'CL-102', name: 'Computer Lab B', building: 'Old Building', floor: '1st Floor', type: 'Computer Laboratory B', capacity: 30, status: 'ACTIVE' },
    { code: 'CL-103', name: 'Computer Lab C', building: 'Annex Building', floor: '2nd Floor', type: 'Computer Laboratory C', capacity: 30, status: 'ACTIVE' },
    { code: 'KL-101', name: 'Kitchen Lab', building: 'Annex Building', floor: '1st Floor', type: 'Kitchen Laboratory', capacity: 25, status: 'ACTIVE' },
    { code: 'R-301', name: 'Room 301', building: 'Old Building', floor: '3rd Floor', type: 'Lecture Room', capacity: 50, status: 'ACTIVE' },
  ];

  const filteredRooms = rooms.filter(room => {
    const matchesSearch = room.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          room.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = selectedType === 'all' || room.type === selectedType;
    const matchesStatus = selectedStatus === 'all' || room.status === selectedStatus;

    return matchesSearch && matchesType && matchesStatus;
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl mb-1" style={{ color: '#002B7F', fontWeight: 700 }}>
            Room Management {isViewOnly && '(View Only)'}
          </h1>
        </div>
        {!isViewOnly && (
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button style={{ backgroundColor: '#002B7F', color: 'white', fontWeight: 600 }}>
                Add Room
              </Button>
            </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle style={{ color: '#002B7F', fontWeight: 700 }}>Add Room</DialogTitle>
            </DialogHeader>
            <div className="grid grid-cols-2 gap-4 py-4">
              <div className="space-y-2">
                <Label className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>ROOM CODE</Label>
                <Input placeholder="e.g. R-401" />
              </div>
              <div className="space-y-2">
                <Label className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>ROOM NAME</Label>
                <Input placeholder="e.g. Room 401" />
              </div>
              <div className="space-y-2">
                <Label className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>BUILDING</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Main Building" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Old Building">Old Building</SelectItem>
                    <SelectItem value="Annex Building">Annex Building</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>FLOOR</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="1st Floor" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1st Floor">1st Floor</SelectItem>
                    <SelectItem value="2nd Floor">2nd Floor</SelectItem>
                    <SelectItem value="3rd Floor">3rd Floor</SelectItem>
                    <SelectItem value="4th Floor">4th Floor</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>TYPE</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Lecture Room" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Lecture Room">Lecture Room</SelectItem>
                    <SelectItem value="Computer Laboratory A">Computer Laboratory A</SelectItem>
                    <SelectItem value="Computer Laboratory B">Computer Laboratory B</SelectItem>
                    <SelectItem value="Computer Laboratory C">Computer Laboratory C</SelectItem>
                    <SelectItem value="Kitchen Laboratory">Kitchen Laboratory</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>CAPACITY</Label>
                <Input type="number" placeholder="40" />
              </div>
              <div className="space-y-2 col-span-2">
                <Label className="text-xs" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>STATUS</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Active" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Active">Active</SelectItem>
                    <SelectItem value="Inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>Cancel</Button>
              <Button style={{ backgroundColor: '#002B7F', color: 'white' }} onClick={() => setIsAddDialogOpen(false)}>Save</Button>
            </div>
          </DialogContent>
          </Dialog>
        )}
      </div>

      <Card className="p-6 border border-gray-200">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
            <Input
              placeholder="Search room..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={selectedType} onValueChange={setSelectedType}>
            <SelectTrigger>
              <SelectValue placeholder="All Types" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="Lecture Room">Lecture Room</SelectItem>
              <SelectItem value="Computer Laboratory A">Computer Laboratory A</SelectItem>
              <SelectItem value="Computer Laboratory B">Computer Laboratory B</SelectItem>
              <SelectItem value="Computer Laboratory C">Computer Laboratory C</SelectItem>
              <SelectItem value="Kitchen Laboratory">Kitchen Laboratory</SelectItem>
            </SelectContent>
          </Select>
          <Select value={selectedStatus} onValueChange={setSelectedStatus}>
            <SelectTrigger>
              <SelectValue placeholder="All Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="ACTIVE">Active</SelectItem>
              <SelectItem value="INACTIVE">Inactive</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b-2" style={{ borderColor: '#002B7F' }}>
                <th className="text-left py-3 px-4" style={{ color: '#002B7F', fontWeight: 600 }}>CODE</th>
                <th className="text-left py-3 px-4" style={{ color: '#002B7F', fontWeight: 600 }}>NAME</th>
                <th className="text-left py-3 px-4" style={{ color: '#002B7F', fontWeight: 600 }}>BUILDING</th>
                <th className="text-left py-3 px-4" style={{ color: '#002B7F', fontWeight: 600 }}>FLOOR</th>
                <th className="text-left py-3 px-4" style={{ color: '#002B7F', fontWeight: 600 }}>TYPE</th>
                <th className="text-left py-3 px-4" style={{ color: '#002B7F', fontWeight: 600 }}>CAPACITY</th>
                <th className="text-left py-3 px-4" style={{ color: '#002B7F', fontWeight: 600 }}>STATUS</th>
                <th className="text-left py-3 px-4" style={{ color: '#002B7F', fontWeight: 600 }}>ACTIONS</th>
              </tr>
            </thead>
            <tbody>
              {filteredRooms.map((room) => (
                <tr key={room.code} className="border-b border-gray-200 hover:bg-gray-50">
                  <td className="py-3 px-4" style={{ color: '#002B7F', fontWeight: 600 }}>{room.code}</td>
                  <td className="py-3 px-4" style={{ color: '#333333', fontWeight: 500 }}>{room.name}</td>
                  <td className="py-3 px-4" style={{ color: '#002B7F', fontWeight: 500 }}>{room.building}</td>
                  <td className="py-3 px-4" style={{ color: '#666666' }}>{room.floor}</td>
                  <td className="py-3 px-4" style={{ color: '#666666' }}>{room.type}</td>
                  <td className="py-3 px-4" style={{ color: '#333333', fontWeight: 600 }}>{room.capacity}</td>
                  <td className="py-3 px-4">
                    <span
                      className="px-3 py-1 rounded text-sm"
                      style={{ backgroundColor: '#22C55E', color: 'white', fontWeight: 600 }}
                    >
                      {room.status}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex gap-2">
                      <button className="p-1 hover:bg-gray-100 rounded">
                        <Eye size={18} style={{ color: '#666666' }} />
                      </button>
                      {!isViewOnly && (
                        <>
                          <button className="p-1 hover:bg-gray-100 rounded">
                            <Edit size={18} style={{ color: '#666666' }} />
                          </button>
                          <button className="p-1 hover:bg-gray-100 rounded">
                            <Trash2 size={18} style={{ color: '#EF4444' }} />
                          </button>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
