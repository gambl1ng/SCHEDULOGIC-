import { Card } from './ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Button } from './ui/button';
import { FileBarChart, Download, Clock, Target } from 'lucide-react';

export function Reports() {
  const reports = [
    { title: 'Faculty Load Report', department: '1,246', icon: FileBarChart },
    { title: 'Faculty Compliance Percentage', value: '94%', icon: Target },
    { title: 'Total Saved', value: '312', icon: FileBarChart },
    { title: 'Active Sections', value: '312', icon: FileBarChart },
  ];

  const summaryReports = [
    { title: 'Faculty Load', description: 'Track and view detailed analysis', actions: ['View', 'Export'] },
    { title: 'Room Utilization', description: 'Track weekly use of rooms', actions: ['View', 'Export'] },
    { title: 'Schedule Dashboard', description: 'Central view of all schedules', actions: ['View', 'Export'] },
    { title: 'Section Schedule', description: 'View all of section schedules', actions: ['View', 'Export'] },
  ];

  const institutionalReports = [
    { title: 'Faculty Load', description: 'Section view of all schedules' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl mb-1" style={{ color: '#002B7F', fontWeight: 700 }}>
            Reports
          </h1>
        </div>
        <div className="flex gap-2">
          <Select defaultValue="1st">
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1st">1st Sem</SelectItem>
              <SelectItem value="2nd">2nd Sem</SelectItem>
            </SelectContent>
          </Select>
          <Select defaultValue="all">
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Departments</SelectItem>
              <SelectItem value="ict">ICT</SelectItem>
              <SelectItem value="business">Business Management</SelectItem>
            </SelectContent>
          </Select>
          <Button style={{ backgroundColor: '#FFD400', color: '#002B7F', fontWeight: 600 }}>
            More Filters
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-6" style={{ backgroundColor: '#002B7F', color: 'white' }}>
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Clock size={20} />
                <p className="text-sm opacity-90">AI OPERATIONAL IMPACT</p>
              </div>
              <h2 className="text-4xl mb-2" style={{ fontWeight: 700 }}>48 Hours Saved</h2>
              <p className="text-sm opacity-80">Time saved by using AI-scheduling vs. manually scheduling last semester</p>
            </div>
          </div>
        </Card>

        <Card className="p-6 border border-gray-200">
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Target size={20} style={{ color: '#002B7F' }} />
                <p className="text-sm" style={{ color: '#666666', fontWeight: 600 }}>AI DEMAND FORECAST</p>
              </div>
              <h2 className="text-4xl mb-2" style={{ color: '#002B7F', fontWeight: 700 }}>94% Accuracy</h2>
              <p className="text-sm" style={{ color: '#666666' }}>Predicting project need for 12 new lab sections based on current student registration trends.</p>
            </div>
          </div>
        </Card>
      </div>

      <Card className="p-6 border border-gray-200">
        <h3 className="text-lg mb-4" style={{ color: '#002B7F', fontWeight: 600 }}>
          Room Utilization
        </h3>
        <div className="flex items-end justify-between h-48">
          <div className="flex items-end gap-4 h-full">
            <div className="flex flex-col justify-end items-center gap-2">
              <div className="w-16 rounded-t" style={{ height: '30%', backgroundColor: '#002B7F' }}></div>
              <span className="text-xs" style={{ color: '#666666' }}>Week 1</span>
            </div>
            <div className="flex flex-col justify-end items-center gap-2">
              <div className="w-16 rounded-t" style={{ height: '45%', backgroundColor: '#002B7F' }}></div>
              <span className="text-xs" style={{ color: '#666666' }}>Week 2</span>
            </div>
            <div className="flex flex-col justify-end items-center gap-2">
              <div className="w-16 rounded-t" style={{ height: '90%', backgroundColor: '#FFD400' }}></div>
              <span className="text-xs" style={{ color: '#666666' }}>Week 3</span>
            </div>
            <div className="flex flex-col justify-end items-center gap-2">
              <div className="w-16 rounded-t" style={{ height: '35%', backgroundColor: '#002B7F' }}></div>
              <span className="text-xs" style={{ color: '#666666' }}>Week 8</span>
            </div>
            <div className="flex flex-col justify-end items-center gap-2">
              <div className="w-16 rounded-t" style={{ height: '25%', backgroundColor: '#002B7F' }}></div>
              <span className="text-xs" style={{ color: '#666666' }}>Week 12</span>
            </div>
          </div>
          <div className="flex gap-4">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3" style={{ backgroundColor: '#002B7F' }}></div>
              <span className="text-xs" style={{ color: '#666666' }}>Lab (45%)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3" style={{ backgroundColor: '#FFD400' }}></div>
              <span className="text-xs" style={{ color: '#666666' }}>Lecture (48%)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 border" style={{ borderColor: '#002B7F' }}></div>
              <span className="text-xs" style={{ color: '#666666' }}>Idle (30%)</span>
            </div>
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-6 border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg" style={{ color: '#002B7F', fontWeight: 600 }}>
              Operational Summary Reports
            </h3>
            <Button size="sm" variant="outline">View All</Button>
          </div>
          <div className="space-y-3">
            {summaryReports.map((report, index) => (
              <div key={index} className="p-3 border rounded-lg hover:bg-gray-50">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 style={{ color: '#002B7F', fontWeight: 600, fontSize: '0.875rem' }}>{report.title}</h4>
                    <p style={{ color: '#666666', fontSize: '0.75rem' }}>{report.description}</p>
                  </div>
                  <div className="flex gap-2">
                    {report.actions.map((action, i) => (
                      <button key={i} className="p-1 hover:bg-gray-100 rounded text-sm">
                        {action}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card className="p-6 border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg" style={{ color: '#002B7F', fontWeight: 600 }}>
              Institutional Master Schedules
            </h3>
            <Button size="sm" variant="outline">View All</Button>
          </div>
          <div className="space-y-3">
            {institutionalReports.map((report, index) => (
              <div key={index} className="p-3 border rounded-lg hover:bg-gray-50">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 style={{ color: '#002B7F', fontWeight: 600, fontSize: '0.875rem' }}>{report.title}</h4>
                    <p style={{ color: '#666666', fontSize: '0.75rem' }}>{report.description}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline">View</Button>
                    <Button size="sm" variant="outline">Export</Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card className="p-6 border border-gray-200">
        <h3 className="text-lg mb-4" style={{ color: '#002B7F', fontWeight: 600 }}>
          Operational Analytics Summary
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <p className="text-xs mb-2" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>Export Volume Breakdown</p>
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: '#002B7F' }}></div>
                <span className="text-sm" style={{ color: '#666666' }}>PDF</span>
                <span className="ml-auto" style={{ color: '#002B7F', fontWeight: 600 }}>45%</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: '#FFD400' }}></div>
                <span className="text-sm" style={{ color: '#666666' }}>XLSX</span>
                <span className="ml-auto" style={{ color: '#002B7F', fontWeight: 600 }}>35%</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: '#E5E7EB' }}></div>
                <span className="text-sm" style={{ color: '#666666' }}>CSV</span>
                <span className="ml-auto" style={{ color: '#002B7F', fontWeight: 600 }}>20%</span>
              </div>
            </div>
          </div>

          <div>
            <p className="text-xs mb-2" style={{ color: '#666666', fontWeight: 600, textTransform: 'uppercase' }}>Weekly Interface Utilization</p>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm" style={{ color: '#666666' }}>Dashboard</span>
                <div className="flex-1 mx-3 h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div className="h-full" style={{ width: '78%', backgroundColor: '#002B7F' }}></div>
                </div>
                <span className="text-sm" style={{ color: '#002B7F', fontWeight: 600 }}>78%</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm" style={{ color: '#666666' }}>Quick Report</span>
                <div className="flex-1 mx-3 h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div className="h-full" style={{ width: '45%', backgroundColor: '#FFD400' }}></div>
                </div>
                <span className="text-sm" style={{ color: '#002B7F', fontWeight: 600 }}>45%</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm" style={{ color: '#666666' }}>Scheduled</span>
                <div className="flex-1 mx-3 h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div className="h-full" style={{ width: '30%', backgroundColor: '#E5E7EB' }}></div>
                </div>
                <span className="text-sm" style={{ color: '#002B7F', fontWeight: 600 }}>30%</span>
              </div>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
